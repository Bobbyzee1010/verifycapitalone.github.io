var c1SiteVars={
    "deviceInfo":{
        "type": "desktop",
        "os":  "device_osWindows NT"
      }
    }
